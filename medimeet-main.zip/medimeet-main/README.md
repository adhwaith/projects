# Medimeet : A Teleconsultation Project

Welcome to Medimeet, a teleconsultation platform that allows users to connect with healthcare professionals through video conferences. This project utilizes React.js for the frontend, Flask and Socket.IO for video conferencing, and MySQL for database management.

## Overview

Medimeet aims to provide a seamless teleconsultation experience for users seeking medical advice. It incorporates modern web technologies such as React.js for a dynamic and responsive user interface, Flask and Socket.IO for real-time video conferencing, and MySQL for efficient data storage and retrieval.

## Features

- User authentication and authorization
- Secure and encrypted video conferencing using Socket.IO
- Patient and doctor profiles with essential information
- Appointment scheduling and management
- Real-time chat during video consultations
- Medical history tracking and storage

## Getting Started

### Prerequisites

Make sure you have the following installed:

- Node.js and npm (for React.js)
- Python and Flask
- MySQL database

### Installation

1. **Clone the repository:**

   ```bash
   git clone https://github.com/opengeekmail/medimeet.git
   cd medimeet
   ```

2. **Install frontend dependencies:**

   ```bash
   cd frontend
   npm install
   npm start

   ```

3. **Install backend dependencies:**

   ```bash
   cd ../backend
   pip install -r requirements.txt
   python app.py

   ```
