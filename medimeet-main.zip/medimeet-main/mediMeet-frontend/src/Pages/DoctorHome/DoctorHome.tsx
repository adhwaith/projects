import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Navbar from '../../Components/Nav/Navbar';
import './DoctorHome.css'

const DoctorHome = () => {
    const [doctorName, setDoctorName] = useState(sessionStorage.getItem('user') || '');
    const navigate = useNavigate();
    const [appointment, setAppointment] = useState([])
    const [completedApp, setCompletedApp] = useState([])
    const [error, setError] = useState('');


    useEffect(() => {
        handleFindBooking();
        handleCompletedBook();
    }, []);

    const handleFindBooking = async () => {
        if (doctorName) {
            try {
                const response = await axios.get(`http://127.0.0.1:5000/doctor/appointments`, {
                    params: { doctor_name: doctorName }
                });
                setAppointment(response.data.appointments)
            } catch (error) {
                setError('An error occurred. Please try again later.');
                console.error('Error during fetch:', error);
            }
        } else {
            console.error('Please enter a doctor name');
        }
    };

    const handleCompletedBook = async () => {
        if (doctorName) {
            try {
                const response = await axios.get(`http://127.0.0.1:5000/view-completed-consultations`, {
                    params: { doctor_name: doctorName }
                });
                setCompletedApp(response.data.completed_consultations)
            } catch (error) {
                setError('An error occurred. Please try again later.');
                console.error('Error during fetch:', error);
            }
        } else {
            console.error('Please enter a doctor name');
        }
    };


    const formatDateTime = (dateString) => {
        const date = new Date(dateString);
        const options = {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
        };
        return date.toLocaleDateString(undefined, options);
    };



    const handleCompleteBtn = async (appointment_id: any) => {
        try {
            await axios.post(`http://127.0.0.1:5000/complete-appointment`, { appointment_id });
            console.log(`Appointment ${appointment_id} marked as completed.`);
            handleFindBooking();
            handleCompletedBook();
        } catch (error) {
            console.error('Error marking appointment as completed:', error);
        }
    };

    return (
        <div className='doctorhomeContainer'>
            <Navbar />
            <div className="mx-5 px-5 m-0 p-0 ">
                {/* {error && <p className="error-message">{error}</p>} */}
                <h6 className='text-start pt-2 doc-title'>Your Pending Appointments</h6>
                <div className="row">
                    {appointment && appointment.length !== 0 ? (
                        appointment.map((app) => (
                            <div key={app.appointment_id} className="col-md-12 m-0 p-0">
                                <div className="doctor-item m-2">
                                    <div className="row m-2 py-1 d-flex flex-row justify-content-center">
                                        <div className="col-1 p-0 m-0 m-auto d-flex flex-row justify-content-center">
                                            <img src="src\assets\patient.png" height={50} alt="" srcSet="" />
                                        </div>
                                        <div className="col-5 m-auto px-2 ">
                                            <p className="patient-name p-0 m-0"> Appointment On: <span className='patient-values'>{formatDateTime(app.appointment_time)}</span></p>
                                            <p className="patient-name p-0 m-0">Patient Name: <span className='patient-values'>{app.patient_name}</span></p>
                                            <div className="row p-0 m-0 d-flex flex-row justify-content-center">
                                                <p className=" col patient-name p-0 m-0">Age: <span className='patient-values'>{app.age}</span></p>
                                                <p className=" col patient-name p-0 m-0">Gender: <span className='patient-values'>{app.gender}</span></p>
                                            </div>
                                            <div className="row p-0 m-0">
                                                <p className="col patient-name p-0 m-0">Height: <span className='patient-values'>{app.height}</span> cm</p>
                                                <p className="col patient-name p-0 m-0">Weight: <span className='patient-values'>{app.weight}</span> kg</p>
                                            </div>
                                        </div>
                                        <div className="col-3 m-auto px-2">
                                            <p className="patient-name p-0 m-0"> Reason for Consultation: <span className='patient-values'>{app.reason}</span></p>
                                            <p className="patient-name p-0 m-0">Symptoms: <span className='patient-values'>{app.symptoms}</span></p>
                                            <p className="patient-name p-0 m-0">Ongoing Medications: <span className='patient-values'>{app.ongoing_medications || "None"}</span> </p>
                                            <p className="patient-name p-0 m-0">Allergies: <span className='patient-values'>{app.allergies}</span> </p>
                                        </div>
                                        <div className="col-3 text-end m-auto">
                                            <button
                                                className="appointment-button px-3 py-2"
                                                onClick={() => handleCompleteBtn(app.appointment_id)} >
                                                Mark as Completed
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="row p-0 m-0 px-4 py-2">
                            <p className='p-0 m-0'>No Pending appointments</p>
                        </div>
                    )}


                </div>
            </div>
            <div className='mx-5 px-5 m-0 p-0'>
                <h6 className='text-start pt-2 doc-title'>Your Completed Appointments </h6>
                {completedApp && completedApp.length !== 0 ? (
                    completedApp.map((capp) => (
                        <div key={capp.appointment_id} className="col-md-12 m-0 p-0">
                            <div className="doctor-item m-2">
                                <div className="row m-2 py-1 d-flex flex-row justify-content-center">
                                    <div className="col-1 p-0 m-0 m-auto d-flex flex-row justify-content-center">
                                        <img src="src\assets\patient.png" height={50} alt="" srcSet="" />
                                    </div>
                                    <div className="col-5 m-auto px-2 ">
                                        <p className="patient-name p-0 m-0"> Appointment On: <span className='patient-values'>{formatDateTime(capp.appointment_time)}</span></p>
                                        <p className="patient-name p-0 m-0">Patient Name: <span className='patient-values'>{capp.patient_name}</span></p>
                                        <div className="row p-0 m-0 d-flex flex-row justify-content-center">
                                            <p className=" col patient-name p-0 m-0">Age: <span className='patient-values'>{capp.age}</span></p>
                                            <p className=" col patient-name p-0 m-0">Gender: <span className='patient-values'>{capp.gender}</span></p>
                                        </div>
                                        <div className="row p-0 m-0">
                                            <p className="col patient-name p-0 m-0">Height: <span className='patient-values'>{capp.height}</span> cm</p>
                                            <p className="col patient-name p-0 m-0">Weight: <span className='patient-values'>{capp.weight}</span> kg</p>
                                        </div>
                                    </div>
                                    <div className="col-3 m-auto px-2">
                                        <p className="patient-name p-0 m-0"> Reason for Consultation: <span className='patient-values'>{capp.reason}</span></p>
                                        <p className="patient-name p-0 m-0">Symptoms: <span className='patient-values'>{capp.symptoms}</span></p>
                                        <p className="patient-name p-0 m-0">Ongoing Medications: <span className='patient-values'>{capp.ongoing_medications || "None"}</span> </p>
                                        <p className="patient-name p-0 m-0">Allergies: <span className='patient-values'>{capp.allergies}</span> </p>
                                    </div>
                                    <div className="col-3 text-end m-auto">
                                        <button
                                            className="btn btn-disabled px-3 py-2"
                                            disabled
                                        >
                                            Completed
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))
                ) : (
                    <div className="row p-0 m-0 px-4 py-2">
                        <p className='p-0 m-0'>No Completed appointments</p>

                    </div>
                )}

            </div>
            {/* <Footer /> */}
        </div>
    );
};

export default DoctorHome;
