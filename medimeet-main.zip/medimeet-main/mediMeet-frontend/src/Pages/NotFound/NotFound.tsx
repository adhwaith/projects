
const NotFound = () => {
  return (
    <div className="container m-auto py-3 " style={{  fontFamily: 'Poppins'}}>
      <div className="row d-flex flex-row justify-content-center">
        <h3 className="text-center">404 Page Not Found</h3>

      </div>
      <div className="row d-flex flex-row justify-content-center">
        <img src="https://cdn.dribbble.com/users/458522/screenshots/7157588/media/737705cec64886f7cc13a6d768b9b36a.jpg?resize=800x600&vertical=center" style={{width:'50vw',height:'auto'}} alt="" />

      </div>
    </div>
  )
}

export default NotFound