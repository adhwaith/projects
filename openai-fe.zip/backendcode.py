from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
from flask_pymongo import PyMongo

import os
# from dotenv import load_dotenv, find_dotenv
import openai

 


 

os.environ["OPENAI_API_KEY"] = "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"

 

 

# Initialize Flask app

app = Flask(__name__)
CORS(app)
app.config["MONGO_URI"] = "mongodb://localhost:27017/openai"
mongo = PyMongo(app)

 

# Define the API route for handling requests

@app.route('/get_response', methods=['POST'])
def chatgpt():

    # Get data from the request
    data = request.get_json()
    user_input = data.get('user_input')  # Extract the user input from the JSON data
    
    # Create a response using the OpenAI API
    response = openai.Completion.create(
        engine="text-davinci-003",  # Use "text-davinci-003" as the engine
        prompt=user_input,
        max_tokens=3000,  # Limit the response to a certain number of tokens
        temperature=0.7  # Adjust the temperature parameter
    )

    reply={
            'user_input':user_input,
            'response':response.choices[0].text
        }

 

    # Extract and return the response text

    return jsonify(reply),201

@app.route('/get-history',methods=['GET'])
def get_history():
    userd = mongo.db.test.find({})
    serialized_user_data = []
    for user in userd:
        user['_id'] = str(user['_id'])
        serialized_user_data.append(user)
    return jsonify(serialized_user_data), 201

@app.route('/save-history',methods=['POST'])
def save_history():
    response_data=request.get_json()
    print(response_data) #remove this after use
    # Aggregate all dictionaries into a single dictionary
    aggregated_dict = {}
    for data_dict in response_data:
        aggregated_dict.update(data_dict)
    mongo.db.test.insert_one(aggregated_dict)
    return jsonify('True'),201

 

if __name__ == '__main__':

    app.run(host='0.0.0.0', port=5000, debug=True)