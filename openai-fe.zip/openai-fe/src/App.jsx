import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import Input from './components/Input/Input';
import Resp from './components/Response/Resp';
import { useState, } from 'react';

function App() {
  const[input,setInput]=useState(' ')
  const [response, setResponse] = useState([]);
  const handleResponse = (responseData) => {
    console.log(responseData)
    setResponse(responseData);
    setInput(responseData.user_input);
    console.log(input)
    console.log(response)
  };
 

  return (
    <>
    
    <Input onResponse={handleResponse} />
    
    </>
  )
}

export default App
