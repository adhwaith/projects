import React, { useState, useEffect } from 'react';
import './Input.css';
import axios from 'axios';
import Resp from '../Response/Resp';

const Input = ({ onResponse }) => {
  const [response1, setResponse1] = useState([]);

  const [input, setInput] = useState('');
  const [history, setHistory] = useState([])


  useEffect(() => {
    async function historydb() {
      try {
        const response = await axios.get('http://127.0.0.1:5000/get-history');
        setHistory(response.data);
      } catch (error) {
        console.log(error);
      }
    }
    historydb()
  }, [input==='']);




  const newchat =async()=>{

    try {
      const body=response1;
      console.log(body)

      const response = await axios.post('http://127.0.0.1:5000/save-history', body);
      setInput('');
      setResponse1([])

    } catch (error) {
      console.log(error);
    }

  }
  const sendQuery = async () => {
    if (input !== '') {
      const body = { 'user_input': input };
  
      try {
        const response = await axios.post('http://127.0.0.1:5000/get_response', body);
        setInput('');
        setResponse1([...response1, response.data]);
  
      } catch (error) {
        console.log(error);
      }
    }
  };
  useEffect(() => {
    console.log(response1);
  }, [response1])
  
  return (
    <>

      <div className='container-fluid ' style={{ backgroundColor: '#D1DBD6' }}>
        <div className='row m-auto '>
          
          <div className="col-3 col-md-3 align-content-center " style={{ backgroundColor: '#D1DBD6' }} >
            <div className="container pt-3 " style={{ height: '80vh', borderRadius: '10px' }} >
              <div className="row mt-1">
                <div className="col-9">
                  <button className='btn btnnew' onClick={newchat}>+    New Chat</button>
                </div>
                <div className="col-3">
                  <button
                    className="btn btncol "
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseWidthExample"
                    aria-expanded="true"
                    aria-controls="collapseWidthExample"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-layout-sidebar-inset" viewBox="0 0 16 16">
                      <path d="M14 2a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1h12zM2 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2H2z" />
                      <path d="M3 4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4z" />
                    </svg>
                  </button>
                </div>
              </div>

              <div>
                <div className="collapse collapse-horizontal show" id="collapseWidthExample">
                  <div className="row my-3" style={{ height: '60vh', overflowY: 'auto', transition: 'max-height 0.5s ease', maxHeight: '60vh' }}>
                    <p>Today</p>
                    {history.map(chat => (
                      <div key={chat._id}>
                        <div>
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-chat-left-dots" viewBox="0 0 16 16">
                            <path d="M14 1a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H4.414A2 2 0 0 0 3 11.586l-2 2V2a1 1 0 0 1 1-1h12zM2 0a2 2 0 0 0-2 2v12.793a.5.5 0 0 0 .854.353l2.853-2.853A1 1 0 0 1 4.414 12H14a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                            <path d="M5 6a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z" />
                          </svg>
                          <span> </span> {chat.user_input}
                        </div>
                        
                        <hr/>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="row">
              <div>
                <img src="" alt="" srcSet="" />
                <h6>Bruce Wayne</h6>

              </div>
            </div>

          </div>

          <div className="col-9  justify-content-bottom" style={{backgroundColor:"#A2B5A9"}}>
            <div className="row" style={{ height: '88vh'}}>
              <Resp res={response1} />
            </div>
            <div className="row pb-3">
              <div className="input-group input-group-lg ">
                <input type="text" className="form-control" placeholder="Enter The Prompt"
                  value={input}
                  onChange={(e) => setInput(e.target.value)} aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg" 
                  style={{ backgroundColor: '#D1DBD6',borderWidth: '2px',borderColor: 'rgb(0, 0, 0)' }} />
                <button className='btn btn-primary ' onClick={sendQuery}>Send</button>
              </div>
            </div>
          </div>
        </div>


      </div>
    </>
  );
};

export default Input;
