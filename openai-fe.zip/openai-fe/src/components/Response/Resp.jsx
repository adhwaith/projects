/* eslint-disable react/prop-types */
import React from 'react'
import './Resp.css';


const Resp = (props) => {
  console.log(props.res)
  return (<>
  {props.res.map((item, index) => (
        <div key={index} className='pt-5 m-0' style={{ backgroundColor: "#A2B5A9",overflowY: 'auto',maxHeight: '88vh' }}>
          <div className='flex-row justify-content-evenly'>
            <h5 className="p-3 m-0 text-end" style={{ backgroundColor: "#97A99E", borderRadius: '30px 30px 0px 30px' }}>
              {item.user_input} : <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" className="bi bi-person-circle " viewBox="0 0 16 16">
                <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                <path fillRule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z" />
              </svg>
            </h5>
          </div>
          <div className=' mx-4 mt-3 p-3 align-content-end ' style={{ backgroundColor: "#A7BBAF", borderRadius: '30px 30px 30px 0px' }}>
            <p className='typing-demo text-start'>{item.response}</p>
          </div>
        </div>
      ))}
  
  
  </>
  )
}

export default Resp;